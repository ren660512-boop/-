# 雪碧大作战 · 好友挑战 v1.3

轻量网页小游戏，八位好友、七场挑战。支持电脑与手机浏览器。

## 在线游玩

- [立即游玩最新版本](https://soda-friends-boss-rush.ren06060512.chatgpt.site/)
- [itch.io 游戏主页](https://ren06060512gmailcom.itch.io/soda-friends)（需上传新版 ZIP 才会更新）

离线游戏包：全部解压后打开 `index.html`。源码仓库：打开 `dist/index.html`。

## 自由选关

首页点击「自由选关」，七关全部开放，任选角色直接挑战。单关胜利后可重战或选择其他好友；失败和暂停时也可返回选关。苦茶籽与酒神作为情侣双人关共同出战。原有「连续挑战」仍按七关顺序进行。

## 操作

- WASD 或方向键移动；按住空格或 J 自动朝最近 Boss 普通攻击。
- E 喝雪碧，恢复最多 34 点生命，每关 3 瓶。满血不会消耗。
- Esc 暂停，切走页面自动暂停。手机使用方向按钮和平 A 按钮。
- 每关补满生命和雪碧，失败直接重试当前关卡。

## 关卡

1. 小狗：上海话文字弹幕、小忧郁波纹；“听说…”谣言气泡可被平 A 打散，1.3 秒后会分裂一次；自封“中山涉黑王”的戏精排场形成三段红毯预警，走出红色区域即可躲避。
2. 简单：昆明人，文字弹幕与算术对决。答对让简单扣血，答错或超时不惩罚玩家。
3. 陆远：首先、其次、因此，三段逻辑预警。
4. 元元：折返的回忆，召唤松鼠冲刺造成暴击；小狗、酒神助阵起哄。
5. 德蔚：三拍音符弹幕留有缺口；“换个角度”与“犀利观点”依次封锁玩家之前的位置；反问与音符会折返。歌声用合成音符与声波表现，不含真人演唱录音。
6. 鸭鸭：分批建仓依次封锁四个区域，绿色留白是安全通道；建仓结束后止盈休息 2.3 秒，玩家对其伤害翻倍；还有涨跌折返弹幕与风险对冲预警。
7. 苦茶籽与酒神：情侣双人关，共用血条，代码封路和重拳合招。

v1.2 新增德蔚、鸭鸭的独立关卡与人物图像、小狗两组新技能；关卡流程扩展为七关，情侣关仍为最终关。

v1.1 新增屋顶夜景背景、原创循环电子 BGM、独立音乐开关与音量、回血快捷键与低血量提醒、命中爆光、气泡拖尾、施法光环、重拳冲击波和回血涟漪。小狗追加“外乡人”“松江最强”“臭外地的”等熟人嘴贫台词。地区梗与上海话文字混用，未包含真人配音或上海话录音。

点击开始后音乐才会播放，以符合浏览器自动播放限制。暂停或切出页面时停止音乐，算术环节降低音乐音量。音乐由 music.js 在设备上合成，不需要下载外部音频，也不调用模型。

角色形象为虚构草图，并非真人肖像。“中山涉黑王”为角色自封的夸张玩笑称号，剧情明确以吹牛收尾。主角显示为“你”，雪碧明确作为回血道具。

## 发布到 itch.io / GitHub Pages

导出的 ZIP 包根目录直接包含 index.html，解压后可离线玩。

itch.io：创建项目 → Kind of project 选择 HTML → 上传 ZIP → 勾选 This file will be played in the browser → 建议嵌入尺寸 1280 × 900，开启全屏按钮与移动端支持 → 预览 → 选择公开可见性。参考：https://itch.io/docs/creators/html5

GitHub：将游戏文件解压上传到你选择的仓库根目录 → Settings → Pages → Deploy from a branch → main / root → 保存。参考：https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

游戏源码无 API 密钥、无付费接口、无玩家账号服务；游玩和音乐在访客浏览器中运行。托管流量仍受所用平台政策与额度约束。

## 检查

v1.2：JavaScript 语法检查通过。逻辑模拟验证了七关击败和逐关推进、谣言分裂与辟谣、德蔚三拍与辩论预警、鸭鸭安全通道及双倍伤害的生效与到期、暂停和重试重置、回血与算术对决、松鼠暴击及情侣合招。BGM 调度测试通过。

## 素材

dist/arena.png：本轮使用内置 Imagegen 生成的屋顶夜景背景，1536 × 1024。生成提示词：Create a polished 1536x1024 2D top-down pixel-art video game arena BACKGROUND ONLY, no UI, no text, no characters. A cozy neon rooftop hangout in a contemporary Chinese city at night, deep navy and teal palette, electric lime accent lights. Orthographic straight overhead view, not isometric. Wide clean rectangular central rooftop play field covers center 85% width and 75% height, with subtle dark tiled floor and faint circular faded paint in middle, uncluttered to read game projectiles. Only along outer perimeter: low parapet walls, small plant pots, rooftop ventilation boxes, a few cafe stools and an unbranded glowing green drink vending machine in top left, warm string lights along upper edge. Tiny skyline and distant windows beyond roof only at far top edge. Stylish detailed crisp pixel art matching anime chibi arcade characters, restrained contrast in central floor, attractive luminous edges. No logos, no lettering, no watermarks, no baked-in interface. Landscape composition.

dist/music.js：原创八小节循环合成旋律，没有使用商业歌曲或外部采样。

dist/characters.png：内置 Imagegen 一次生成，1536 × 1024，四列两行。以下为生成提示词。绘图结果为深色背景，游戏以卡牌形式展示；酒神当前立绘仍可继续调整得更偏男性化。

Use case: stylized-concept. Asset type: live Canvas game sprite sheet, not a mockup. Generate one 1536x1024 PNG, exactly four equal columns and two equal rows, with eight isolated full-body sprites. Each cell is 384x512. Place each sprite centrally inside its cell, with generous empty margin and feet at consistent baseline, no sprite crossing cell boundaries. Clean genuine transparent background preferred; if transparency unavailable use perfectly flat solid dark navy #111c32. No grid lines, no labels, no lettering, no scenery, no shadows outside silhouettes. Detailed charming crisp pixel art, chibi proportions but unmistakably adult human characters, consistent scale, clean readable silhouettes, front-facing slight three-quarter view. Seven Chinese adult characters and one squirrel. Row 1 left to right: (1) protagonist with short black hair in mint-green hoodie holding a small green soda can; (2) Xiaogou, cheerful young adult man from Shanghai, orange dog-ear hoodie; (3) Jiandan, handsome stylish adult male nightclub model aesthetic, black and gold blazer with open collar, holding a book; (4) Luyuan, handsome adult male lawyer, navy suit, silver glasses, holding paper. Row 2 left to right: (5) Yuanyuan, young adult woman wearing violet jacket, wistful expression, holding phone; (6) Kuchazi, adult male programmer, glasses, teal hoodie, holding laptop; (7) Jiushen, masculine-presenting adult woman, short dark hair, loose black jacket, broad relaxed stance, tired stoic face; (8) cute copper-colored squirrel summon with large curled tail. Keep the exact order and uniform regular 4x2 grid. Full bodies including footwear and all props entirely contained. No additional characters, no text, no watermark.


dist/new-friends.png：内置 Imagegen 单次生成的两列人物头像，左德蔚、右鸭鸭。Prompt: Create one 2:1 raster game portrait sprite sheet with two equal square cells, using the existing characters.png as style reference. Polished East Asian anime chibi cel-shaded busts. Left: 德蔚, charismatic young adult male singer/debater, clever confident expression, dark tousled hair, teal/cyan stage jacket, handheld microphone. Right: 鸭鸭, stylish adult investment strategist, thoughtful confident expression, dark hair, gold/amber tailored outfit, round glasses, small duck lapel pin. Center each portrait in its cell, suitable for circular crops, flat dark navy background, cyan and gold neon rimlight, strong silhouettes. No text, labels, logos, watermark, divider, or extra characters.
